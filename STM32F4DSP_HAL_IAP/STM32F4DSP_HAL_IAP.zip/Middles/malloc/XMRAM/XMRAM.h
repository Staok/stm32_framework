

int XmRamInit(void);
