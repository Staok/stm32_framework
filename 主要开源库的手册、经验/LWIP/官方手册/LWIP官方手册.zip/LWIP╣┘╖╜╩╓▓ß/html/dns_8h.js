var dns_8h =
[
    [ "DNS_TMR_INTERVAL", "dns_8h.html#a464a7435c4c00735af59033d2acd83bb", null ],
    [ "dns_found_callback", "dns_8h.html#ab5a9dec5b22802f91876c53e99f427ae", null ],
    [ "dns_gethostbyname", "group__dns.html#ga1e040ec38166dc9bfcc3473aab0c799f", null ],
    [ "dns_gethostbyname_addrtype", "group__dns.html#gae84449f60dca6b863142daca8e03ce79", null ],
    [ "dns_getserver", "group__dns.html#gad02111a6b26b93f1c3580d5f41a59af3", null ],
    [ "dns_init", "dns_8h.html#adb31c3b6180773bd11f914c327f209cf", null ],
    [ "dns_setserver", "group__dns.html#gaf66c5d8273f83cdc2cdd8911fb68d584", null ],
    [ "dns_tmr", "dns_8h.html#a9389f374ec66488aa4f42a652583f533", null ]
];