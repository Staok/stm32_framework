#ifndef __I2C_H
#define __I2C_H
#endif



#define IIC_SCL GPIO_Pin_4
#define IIC_SDA GPIO_Pin_5
#define GPIO_IIC GPIOI
//#define IIC_SCL_H GPIO_SetBits(GPIO_IIC,IIC_SCL) 
//#define IIC_SCL_L GPIO_ResetBits(GPIO_IIC,IIC_SCL)
#define IIC_SDA_H GPIO_SetBits(GPIO_IIC,IIC_SDA)
#define IIC_SDA_L GPIO_ResetBits(GPIO_IIC,IIC_SDA)
#define SDA_read      GPIOI->IDR  & GPIO_Pin_5  
#define SCL_read      GPIOI->IDR  & GPIO_Pin_4
void IIC_Init_ZC(void);
void IIC_SDA_OUT(void);
void IIC_SDA_IN(void);
void IIC_Start(void);
void IIC_Stop(void);
void IIC_Ack(void);
void IIC_Nack(void);
u8 IIC_Wait_Ack(void);
void IIC_Send_Byte(u8 txd);
u8 IIC_Read_Byte();
void IIC_SCL_H(void);
void IIC_SCL_L(void);