var group__pmu8__events__armcm55 =
[
    [ "ARMCM55_PMU_DOSTIMEOUT_DOUBLE", "group__pmu8__events__armcm55.html#ga8b005f5e47bc8bf9ee8d84a43b798ca9", null ],
    [ "ARMCM55_PMU_DOSTIMEOUT_TRIPLE", "group__pmu8__events__armcm55.html#ga6bf0106f269b33afbe3482bab385f152", null ],
    [ "ARMCM55_PMU_ECC_ERR", "group__pmu8__events__armcm55.html#gab423c79d244d071407afb49dfcfb6e05", null ],
    [ "ARMCM55_PMU_ECC_ERR_DCACHE", "group__pmu8__events__armcm55.html#gaa644074ec71c49e7e7a45d001bbdfb00", null ],
    [ "ARMCM55_PMU_ECC_ERR_DTCM", "group__pmu8__events__armcm55.html#gaca4db507dab60fce8df90f1a4bb862ad", null ],
    [ "ARMCM55_PMU_ECC_ERR_FATAL", "group__pmu8__events__armcm55.html#ga88ab1b9d04cd44c53a92962fad8e3bdc", null ],
    [ "ARMCM55_PMU_ECC_ERR_FATAL_DCACHE", "group__pmu8__events__armcm55.html#ga45cc9a0330e159e4afbce93e3cb5ef2e", null ],
    [ "ARMCM55_PMU_ECC_ERR_FATAL_DTCM", "group__pmu8__events__armcm55.html#gad82225c528aa89689684fe5ddbe3c637", null ],
    [ "ARMCM55_PMU_ECC_ERR_FATAL_ICACHE", "group__pmu8__events__armcm55.html#gabe33023adf35df68a949d13212c379eb", null ],
    [ "ARMCM55_PMU_ECC_ERR_FATAL_ITCM", "group__pmu8__events__armcm55.html#ga0ed17ac3f8d8865e85d9690cbb51a06b", null ],
    [ "ARMCM55_PMU_ECC_ERR_ICACHE", "group__pmu8__events__armcm55.html#ga7e31a482a7cf6bf6467487dcf2f89181", null ],
    [ "ARMCM55_PMU_ECC_ERR_ITCM", "group__pmu8__events__armcm55.html#gafc07c84258939e22cdb3b2e98dee0ac6", null ],
    [ "ARMCM55_PMU_NWAMODE", "group__pmu8__events__armcm55.html#gab3f4da2771d4ca5edc9822d9a5353994", null ],
    [ "ARMCM55_PMU_NWAMODE_ENTER", "group__pmu8__events__armcm55.html#gaf3fcaa27702154d0739863b6462b8d73", null ],
    [ "ARMCM55_PMU_PF_CANCEL", "group__pmu8__events__armcm55.html#gad10f5c84036644353ee2dfb14b8e9f48", null ],
    [ "ARMCM55_PMU_PF_DROP_LINEFILL", "group__pmu8__events__armcm55.html#ga1fafa33dc3bfb8f717fa04a0b868353c", null ],
    [ "ARMCM55_PMU_PF_LINEFILL", "group__pmu8__events__armcm55.html#gad433a568f1a7ae448807f9e71173e6c2", null ],
    [ "ARMCM55_PMU_SAHB_ACCESS", "group__pmu8__events__armcm55.html#gaadf0341d6a67cd30481201e7a3c7e77b", null ]
];