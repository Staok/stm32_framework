var group__netdbapi =
[
    [ "freeaddrinfo", "group__netdbapi.html#gab28cd3049bcf6e2bc3a71e968a64a92d", null ],
    [ "getaddrinfo", "group__netdbapi.html#ga558191530d91c101621b49e43bd5bbf5", null ],
    [ "gethostbyname", "group__netdbapi.html#ga39746b4b096060ca3e8c6ee7a7560b1d", null ],
    [ "gethostbyname_r", "group__netdbapi.html#ga76204a4d646dba393f88aa9b0980fc07", null ]
];