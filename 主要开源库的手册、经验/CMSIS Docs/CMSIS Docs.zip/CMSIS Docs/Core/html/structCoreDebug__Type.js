var structCoreDebug__Type =
[
    [ "DCRDR", "structCoreDebug__Type.html#aab3cc92ef07bc1f04b3a3aa6db2c2d55", null ],
    [ "DCRSR", "structCoreDebug__Type.html#af907cf64577eaf927dac6787df6dd98b", null ],
    [ "DEMCR", "structCoreDebug__Type.html#aeb3126abc4c258a858f21f356c0df6ee", null ],
    [ "DHCSR", "structCoreDebug__Type.html#ad63554e4650da91a8e79929cbb63db66", null ]
];