var group__coreregister__trustzone__functions =
[
    [ "__TZ_get_BASEPRI_NS", "group__coreregister__trustzone__functions.html#ga624509c924d2583f0d4dca6ab270f051", null ],
    [ "__TZ_get_CONTROL_NS", "group__coreregister__trustzone__functions.html#ga27bf1f88e794c30808ee73a29d46e358", null ],
    [ "__TZ_get_FAULTMASK_NS", "group__coreregister__trustzone__functions.html#ga578b41087f207e1a475daae6cc8a28dc", null ],
    [ "__TZ_get_MSP_NS", "group__coreregister__trustzone__functions.html#gab3aa15eb4f352e230b9f7a3e8856a9e9", null ],
    [ "__TZ_get_MSPLIM_NS", "group__coreregister__trustzone__functions.html#gada00853d3e49fa8d21f375c53d28fa51", null ],
    [ "__TZ_get_PRIMASK_NS", "group__coreregister__trustzone__functions.html#ga7cc3271c79e619f8838e8767df3cb509", null ],
    [ "__TZ_get_PSP_NS", "group__coreregister__trustzone__functions.html#ga40ff8336c6d09af6da1081d4e4adc126", null ],
    [ "__TZ_get_PSPLIM_NS", "group__coreregister__trustzone__functions.html#ga5da646ec291b6a183f38497ce92be51c", null ],
    [ "__TZ_get_SP_NS", "group__coreregister__trustzone__functions.html#gaaaf2aaf904b25ed17fd3e5e63f8e029b", null ],
    [ "__TZ_set_BASEPRI_NS", "group__coreregister__trustzone__functions.html#ga92c187f0b4d53627b59e0fd0bda0b0df", null ],
    [ "__TZ_set_CONTROL_NS", "group__coreregister__trustzone__functions.html#ga3eb150204e6d389d5b49065179b9cde5", null ],
    [ "__TZ_set_FAULTMASK_NS", "group__coreregister__trustzone__functions.html#ga4f0912db7bc65439d23817c1d372a7a4", null ],
    [ "__TZ_set_MSP_NS", "group__coreregister__trustzone__functions.html#ga41c3ac2d9af23c40647c053ad7d564e7", null ],
    [ "__TZ_set_MSPLIM_NS", "group__coreregister__trustzone__functions.html#gad2013f4d4311d6db253594a12d192617", null ],
    [ "__TZ_set_PRIMASK_NS", "group__coreregister__trustzone__functions.html#ga6686c2ab5756b5049fad1644e89b3340", null ],
    [ "__TZ_set_PSP_NS", "group__coreregister__trustzone__functions.html#gaea8db21c00cfa4144ee74dc65dbd7580", null ],
    [ "__TZ_set_PSPLIM_NS", "group__coreregister__trustzone__functions.html#ga81e0995ee0fd2a9dcd9e9681bc22c76f", null ],
    [ "__TZ_set_SP_NS", "group__coreregister__trustzone__functions.html#gab7263167cb006aeeb04b68e579dae015", null ]
];