var globals_func =
[
    [ "a", "globals_func.html", null ],
    [ "b", "globals_func_b.html", null ],
    [ "d", "globals_func_d.html", null ],
    [ "e", "globals_func_e.html", null ],
    [ "h", "globals_func_h.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "l", "globals_func_l.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "n", "globals_func_n.html", null ],
    [ "p", "globals_func_p.html", null ],
    [ "r", "globals_func_r.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "t", "globals_func_t.html", null ],
    [ "u", "globals_func_u.html", null ],
    [ "z", "globals_func_z.html", null ]
];