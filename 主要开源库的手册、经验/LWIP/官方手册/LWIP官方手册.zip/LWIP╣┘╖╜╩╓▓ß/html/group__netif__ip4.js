var group__netif__ip4 =
[
    [ "netif_ip4_addr", "group__netif__ip4.html#gac9b6e63b5dd2968fe0a4813f3eefb55d", null ],
    [ "netif_ip4_gw", "group__netif__ip4.html#ga86d69faf416765b7f8faf60a43cc50da", null ],
    [ "netif_ip4_netmask", "group__netif__ip4.html#ga952d1436f2428b92fc8197bcf2f8fca3", null ],
    [ "netif_ip_addr4", "group__netif__ip4.html#ga54179a2f3b7cc35b23ee8d692d8d8022", null ],
    [ "netif_ip_gw4", "group__netif__ip4.html#ga7ea95478e000701423b7f6316e575a2a", null ],
    [ "netif_ip_netmask4", "group__netif__ip4.html#ga58518602f388d2640985a01a312f0a51", null ],
    [ "netif_set_addr", "group__netif__ip4.html#ga85e31a68e96390dab2feffb11f4948a1", null ],
    [ "netif_set_gw", "group__netif__ip4.html#ga841876c274c3c90898579f9e12f3b520", null ],
    [ "netif_set_ipaddr", "group__netif__ip4.html#ga73b043a7ec0e4899aba8433ec9064cca", null ],
    [ "netif_set_netmask", "group__netif__ip4.html#ga0bdd7c057c2f55f670853e3906014a53", null ]
];