var searchData=
[
  ['mpu_20functions_20for_20armv8_2dm',['MPU Functions for Armv8-M',['../group__mpu8__functions.html',1,'']]],
  ['mpu_20functions_20for_20armv6_2dm_2fv7_2dm',['MPU Functions for Armv6-M/v7-M',['../group__mpu__functions.html',1,'']]],
  ['mve_20functions',['MVE Functions',['../group__mve__functions.html',1,'']]]
];
