var searchData=
[
  ['peripheral_20access',['Peripheral Access',['../group__peripheral__gr.html',1,'']]],
  ['pmu_20events_20for_20cortex_2dm55',['PMU Events for Cortex-M55',['../group__pmu8__events__armcm55.html',1,'']]],
  ['pmu_20events_20for_20armv8_2e1_2dm',['PMU Events for Armv8.1-M',['../group__pmu8__events__armv81.html',1,'']]],
  ['pmu_20functions_20for_20armv8_2e1_2dm',['PMU Functions for Armv8.1-M',['../group__pmu8__functions.html',1,'']]]
];
