var group__CMSIS__CNTP__CTL =
[
    [ "__get_CNTP_CTL", "group__CMSIS__CNTP__CTL.html#gaca4b93d7543b49c1d7e6b4e1c1ff3768", null ],
    [ "__set_CNTP_CTL", "group__CMSIS__CNTP__CTL.html#ga96a537cd4e121d58aa9f7d2bfccaa66d", null ]
];