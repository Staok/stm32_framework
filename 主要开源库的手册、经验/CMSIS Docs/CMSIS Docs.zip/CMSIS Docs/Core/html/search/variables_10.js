var searchData=
[
  ['scr',['SCR',['../structSCB__Type.html#a3a4840c6fa4d1ee75544f4032c88ec34',1,'SCB_Type']]],
  ['shcsr',['SHCSR',['../structSCB__Type.html#a7b5ae9741a99808043394c4743b635c4',1,'SCB_Type']]],
  ['shp',['SHP',['../structSCB__Type.html#a85768f4b3dbbc41fd760041ee1202162',1,'SCB_Type']]],
  ['sleepcnt',['SLEEPCNT',['../structDWT__Type.html#a416a54e2084ce66e5ca74f152a5ecc70',1,'DWT_Type']]],
  ['sppr',['SPPR',['../structTPI__Type.html#a12f79d4e3ddc69893ba8bff890d04cc5',1,'TPI_Type']]],
  ['spsel',['SPSEL',['../unionCONTROL__Type.html#a8cc085fea1c50a8bd9adea63931ee8e2',1,'CONTROL_Type']]],
  ['sspsr',['SSPSR',['../structTPI__Type.html#a7b72598e20066133e505bb781690dc22',1,'TPI_Type']]],
  ['stir',['STIR',['../structNVIC__Type.html#a37de89637466e007171c6b135299bc75',1,'NVIC_Type']]],
  ['swinc',['SWINC',['../structPMU__Type.html#a2add0abae68f27801299d6dd4bfcde66',1,'PMU_Type']]],
  ['systemcoreclock',['SystemCoreClock',['../group__system__init__gr.html#gaa3cd3e43291e81e795d642b79b6088e6',1,'Ref_SystemAndClock.txt']]]
];
