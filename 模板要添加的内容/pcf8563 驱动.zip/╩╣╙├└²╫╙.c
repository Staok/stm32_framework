
初始化序列：
IIC_Init_ZC();
PCF8563_Start();
PCF8563_SetMode(PCF_Mode_Normal);


//设置时间 设置一次就行了 设置为2021.1.22 星期5 16点15，使用 BIN 16进制格式
PCF8563_Set_Times(PCF_Format_BIN,PCF_Century_20xx,0x15,0x01,0x1f,0x07,0x0f,0x05); 




得到当前时间：
PCF8563_GetTime( PCF_Format_BIN, &Get_Time);
PCF8563_GetDate( PCF_Format_BIN, &Get_Date);


Get_Date.RTC_Years;
Get_Date.RTC_Months;
Get_Date.RTC_Days;
Get_Time.RTC_Hours;
Get_Time.RTC_Minutes;
Get_Time.RTC_Seconds;
