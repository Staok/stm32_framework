var group__smtp__opts =
[
    [ "SMTP_BODYDH", "group__smtp__opts.html#ga4b1667149354b7819847cb4f5f1ff144", null ],
    [ "SMTP_CHECK_DATA", "group__smtp__opts.html#ga021d8133159895a2dbf5fb0b243da9fa", null ],
    [ "SMTP_COPY_AUTHDATA", "group__smtp__opts.html#gab5559a7c976e72204d9391f655bcc07e", null ],
    [ "SMTP_DEBUG", "group__smtp__opts.html#gae7ea4f31c521947d5127e268ae02c317", null ],
    [ "SMTP_MAX_PASS_LEN", "group__smtp__opts.html#ga9aa5f5529121a8266947f33c5e424ccc", null ],
    [ "SMTP_MAX_SERVERNAME_LEN", "group__smtp__opts.html#gaee3b273524a2253ce5fb44b240b0371b", null ],
    [ "SMTP_MAX_USERNAME_LEN", "group__smtp__opts.html#gafa0c84e5279b8eb8a5dbea6fe97aa099", null ],
    [ "SMTP_SUPPORT_AUTH_LOGIN", "group__smtp__opts.html#ga7a83e686b109fa59557c13736aeeab3b", null ],
    [ "SMTP_SUPPORT_AUTH_PLAIN", "group__smtp__opts.html#ga2e6c8313006592884e89bbcf353cf5ac", null ]
];