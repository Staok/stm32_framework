#include "i2c.h"


/* I2C���ų�ʼ�� */
void IIC_Init_ZC(void)
{
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOI, ENABLE);

  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Pin=GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;  
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOI,&GPIO_InitStructure);
  
  GPIO_InitStructure.GPIO_Pin=GPIO_Pin_5 ;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  //GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOI,&GPIO_InitStructure);    

  GPIO_InitStructure.GPIO_Pin=GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;  
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOI,&GPIO_InitStructure);
}

/* �趨 SDA ��Ϊ���ģʽ */
void IIC_SDA_OUT(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Pin=IIC_SDA;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOI,&GPIO_InitStructure);  
}

/* �趨 SDA ��Ϊ����ģʽ */
void IIC_SDA_IN(void)
{
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOI, ENABLE);
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Pin=IIC_SDA;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 // GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;  
  GPIO_Init(GPIOI,&GPIO_InitStructure);  
}

void IIC_SCL_H(void)
{
  GPIO_SetBits(GPIO_IIC,IIC_SCL) ;
 // GPIO_SetBits(GPIOB,GPIO_Pin_15) ;
}
void IIC_SCL_L(void)
{
  GPIO_ResetBits(GPIO_IIC,IIC_SCL) ;
//  GPIO_ResetBits(GPIOB,GPIO_Pin_15) ;
}

//��ʼ�ź�
void IIC_Start(void)
{
  IIC_SDA_OUT();
  IIC_SDA_H;
  IIC_SCL_H();
 // GPIO_SetBits(GPIOH,GPIO_Pin_7);
//  GPIO_SetBits(GPIOB,GPIO_Pin_15);
  delay_us(5);
  IIC_SDA_L;
  delay_us(6);
  IIC_SCL_L();
}

//����ֹͣ�ź�

void IIC_Stop(void)
{
  IIC_SDA_OUT();
  IIC_SCL_L();
  IIC_SDA_L;
  IIC_SCL_H();
  delay_us(6);
  IIC_SDA_H;
  delay_us(6);
}

// ����Ӧ���ź�
void IIC_Ack(void)
{
  IIC_SCL_L();
  IIC_SDA_OUT();
  IIC_SDA_L;
  delay_us(2);
  IIC_SCL_H();
  delay_us(5);
  IIC_SCL_L();
}

//��Ӧ��
void IIC_Nack(void)
{
  IIC_SCL_L();
  IIC_SDA_OUT();
  IIC_SDA_H;
  delay_us(2);
  IIC_SCL_H();
  delay_us(5);
  IIC_SCL_L(); 
}

//�ȴ��ӻ�Ӧ���ź�
//����ֵ 1 ����Ӧ��ʧ�� 
//����ֵ 0 ����Ӧ��ɹ�
u8 IIC_Wait_Ack(void)
{
    u8 temptime = 0;
    IIC_SDA_IN();
    IIC_SDA_H;
    delay_us(1);
    IIC_SCL_H();
    delay_us(1);
    while(GPIO_ReadInputDataBit(GPIO_IIC , IIC_SDA))
    {
      temptime++;
      if(temptime > 250)
      {
        IIC_Stop();
        return 1;
      }
       
    }
    IIC_SCL_L();
    return 0;  
}


//����һ���ֽ�
void IIC_Send_Byte( u8 txd)
{
  u8 i = 0;
  IIC_SDA_OUT();
  IIC_SCL_L();   // ����ʱ�ӿ�ʼ���ݴ���
  for(i = 0;i < 8;i++)
  {
    if((txd&0x80)>>7)  
               IIC_SDA_H;
            else  
               IIC_SDA_L;  
            txd<<=1;      
            delay_us(2);    
            IIC_SCL_H() ; 
            delay_us(2);   
            IIC_SCL_L();    
            delay_us(2);
  }
}
    
    
// ��ȡһ���ֽ�
u8 IIC_Read_Byte() // u8 ack
{
  u8 i = 0,receive = 0;
  
  IIC_SDA_H;
  IIC_SDA_IN();
  for(i = 0;i < 8;i++)
  {
    IIC_SCL_L();
    delay_us(5);
    IIC_SCL_H();
    receive <<= 1;
    if(SDA_read)//GPIO_ReadInputDataBit(GPIO_IIC , IIC_SDA)  
    {
      receive ++;  // ĩλ��һ
    }
    delay_us(5);
  }
 // if(ack == 0)
 // {
  //  IIC_Nack();
  //}
 // else
 //   IIC_Ack();
  return receive;
}
     