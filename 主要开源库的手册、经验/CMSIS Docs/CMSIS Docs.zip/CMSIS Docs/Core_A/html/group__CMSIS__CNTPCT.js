var group__CMSIS__CNTPCT =
[
    [ "__get_CNTPCT", "group__CMSIS__CNTPCT.html#ga42643f577dcc957d6928e170ce7a2d60", null ]
];