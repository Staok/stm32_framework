#include "TaskConfig.h"


/*********************************************************************************************/
/*                      以下为要修改的部分                                                   */
/********************************************************************************************/

//按照序号给每个任务编号向下写
#define start_t 0
#define led0_t 1
#define led1_t 2

//设置任务要素
struct TaskStructure Define_Task[] = {
    {start_task,    "start_task",   128,        NULL,       2,},
    {led0_task,     "led0_task",    50,         NULL,       2,},
    {led1_task,     "led1_task",    50,         NULL,       3,},
};  //任务函数      任务名称      分配堆栈    传入参数   任务优先级
/*注；堆栈实际占用字节数为定义数的四倍，即定义数的单位为字*/

//struct TaskStructure Define_Task0 = {
//    .Task_Function = start_task,
//    .Task_Name = "ss",
//};

//创建开始任务，这部分固定的不用动
void Task_Init(void)
{
	BaseType_t is_error;
	//创建开始任务	
    is_error = xTaskCreate( Define_Task[start_t].Task_Function,
                            Define_Task[start_t].Task_Name,
                            Define_Task[start_t].Task_STK_Size,
                            Define_Task[start_t].Task_Para,
                            Define_Task[start_t].Task_Prio,
                            &Define_Task[start_t].Task_Handle);//任务句柄，创建任务这里取地址
	if(is_error == pdPASS)
    {
        vTaskStartScheduler();          //开启任务调度
    }else{
        for(;;){;}
    }
}


//开始初始化任务函数
void start_task(void *pvParameters)
{
    taskENTER_CRITICAL();           //进入临界区
	
	//进行队列、信号量等相关的初始化
    
	
	//进行任务相关的初始化
    xTaskCreate(Define_Task[led0_t].Task_Function,
                Define_Task[led0_t].Task_Name,
				Define_Task[led0_t].Task_STK_Size,
				Define_Task[led0_t].Task_Para,
				Define_Task[led0_t].Task_Prio,
				&Define_Task[led0_t].Task_Handle);
    
    xTaskCreate(Define_Task[led1_t].Task_Function,
				Define_Task[led1_t].Task_Name,
				Define_Task[led1_t].Task_STK_Size,
				Define_Task[led1_t].Task_Para,
				Define_Task[led1_t].Task_Prio,
				&Define_Task[led1_t].Task_Handle);
    
    vTaskDelete(Define_Task[start_t].Task_Handle); 
    //删除开始任务，内存也被释放掉，删除任务这里放任务句柄，不取地址
	
    taskEXIT_CRITICAL();            //退出临界区
}


void led0_task(void *pvParameters)
{
	/*本任务所用的变量的定义，第一次运行需要设置的内容，或者本任务只需要运行一次的内容*/
	float staok = 666.0;
	//LED0 = ON;
	
	
	//进入本任务的主循环
    for(;;)
    {
        staok += 0.1;
        vTaskDelay(500);
    }
	
	/*不能从任务函数中退出，除非提前删除任务，否则会调用configASSERT()引起错误*/
}   


void led1_task(void *pvParameters)
{
    for(;;)
    {
        ////LED0=~LED0;
        vTaskDelay(500);
    }
}


